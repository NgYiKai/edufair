<!DOCTYPE html>
<html>

<?php
  echo '<link rel="stylesheet" href="../design/random.css">';
  ?>
  
<body>

<h1>Index Page</h1>

<p><a href='Interface/Register_page.php' target="_blank"; >Register</a></p>
<br>
<p><a href='Interface/Menu_Page.php' target="_blank"; >Menu Page</a></p>
<br>
<p><a href='Interface/chatbot.php' target="_blank"; >Chatbot</a></p>
<br>
<p><a href='Admin_Interface/AdminQueue.php' target="_blank"; >Admin Queue</a></p>
<br>
<p><a href='Interface/Staff-Signin.php' target="_blank"; >Staff Sign In Page</a></p>
<br>
<p><a href='http://localhost:8080/phpmyadmin' target="_blank"; >Database</a></p>




</body>
</html>